*******************************************************************************
*                    ET:Legacy Windows Omni-Bot pack                          *
*                                                                             *
*       based on revision 2497 of the omnibot-et public repository            *
*                https://www.assembla.com/spaces/omnibot/                     *
*******************************************************************************

For any questions and issues related to this pack use the ET_Legacy forums at
http://www.etlegacy.com/projects/etlegacy/boards 

For info about Omni-Bot and additional waypoint files consult 
http://www.omni-bot.com and http://www.omni-bot.com/wiki/index.php

Note: 
This pack doesn't include all available waypoint files for maps. Find more at
http://trac.assembla.com/omnibot/browser/Enemy-Territory/0.8/et/incomplete_navs
